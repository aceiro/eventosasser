<?php
class BaseDataTransferObject{
    public $id;

    public function __construct()
    {
    }


}