<?php

    return array(
        //
        // par�metros gerais para a app
        'title'     => 'Eventos Asser',

        //
        // par�metros gerais para o banco de dados
        'dbname'    => 'eventosa_1sem2016',
        'dsn'       => "mysql:host=localhost;dbname=eventosa_1sem2016",
        'dbuser'    => 'root',
        'dbpass'    => '123456'
    );